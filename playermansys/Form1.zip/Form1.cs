﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NETAssign2
{
    public enum Race { Orc, Troll, Tauren, Forsaken };

    public enum Class { Warrior, Mage, Druid, Priest, Warlock, Rogue, Paladin, Hunter, Shaman };

    public enum Role { Tank, Healer, DPS };

    public partial class Form1 : Form
    {
        List<Guild> guildsarray = new List<Guild>();
        string formatedtext;
        int selectedindex = -1;
        int selectedplayerindex = -1;
        string[] splitplayers;
        List<Player> playerList = new List<Player>();
        string players;
        public Form1()
        {
            InitializeComponent();
            serverComboBox.Items.Add("Beta4Azeroth");
            serverComboBox.Items.Add("TKWasASetback");
            serverComboBox.Items.Add("ZappyBoi");
            typeComboBox.Items.Add("Causal");
            typeComboBox.Items.Add("Questing");
            typeComboBox.Items.Add("Mythic+");
            typeComboBox.Items.Add("Raiding");
            typeComboBox.Items.Add("PVP");


            using (StreamReader inFile = new StreamReader("players.txt"))
            {
                players = inFile.ReadLine();

                for (int i = 0; players != null; i++)
                {
                    splitplayers = players.Split('\t');

                    Race foo = (Race)Enum.Parse(typeof(Race), splitplayers[2]);
                    Class bar = (Class)Enum.Parse(typeof(Class), splitplayers[3]);

                    Player newPlayer = new Player(Convert.ToUInt32(splitplayers[0]), splitplayers[1], foo, bar, Convert.ToUInt32(splitplayers[4]), Convert.ToUInt32(splitplayers[5]), Convert.ToUInt32(splitplayers[6]));
                    playerList.Insert(0, newPlayer);
                    playersListBox.Items.Add(newPlayer.ToString());
                    players = inFile.ReadLine();
                }
            }


            using (StreamReader inFile = new StreamReader("guilds.txt"))
            {
                string guildtext = inFile.ReadLine();
                int counter = 0;
                for (int i = 0; guildtext != null; i++)
                {
                    string[] splitguildtext = guildtext.Split('\t');
                    string[] splitguildtext2 = splitguildtext[1].Split('-');

                    guildsarray.Insert(i, new Guild(Convert.ToUInt32(splitguildtext[0]), splitguildtext2[0], splitguildtext2[1]));
                    guildtext = inFile.ReadLine();
                    formatedtext = String.Format("{0, -25} {1,15}", guildsarray[i].Name, guildsarray[i].Server);
                    listBox1.Items.Add(formatedtext);
                    counter++;
                }
            }

        }

        private void playersListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            selectedplayerindex = playersListBox.SelectedIndex;
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            selectedindex = listBox1.SelectedIndex;
        }

        private void addGuildButton_Click(object sender, EventArgs e)
        {
            Random rnd = new Random();
            int myRandomNo = rnd.Next(10000000, 99999999);
            if (GuildName != null && typeComboBox != null && serverComboBox != null) {
                guildsarray.Add(new Guild(Convert.ToUInt32(myRandomNo), GuildName.Text, serverComboBox.Text));
            }
            formatedtext = String.Format("{0, -25} {1,15}", guildsarray[guildsarray.Count() - 1].Name, guildsarray[guildsarray.Count() - 1].Server);

            listBox1.Items.Add(formatedtext);
        }

        private void disbandGuild_Click(object sender, EventArgs e)
        {
            if(selectedindex != -1)
            {
                guildsarray.Remove(guildsarray[selectedindex]);
                listBox1.Items.RemoveAt(selectedindex);
                selectedindex = -1;
            }
        }

        private void printGuildRoster_Click(object sender, EventArgs e)
        {
            richTextBox1.Clear();
            if(selectedindex != -1)
            {
                for(int i = 0; i < playerList.Count(); i++)
                {
                    if(playerList[i].GuildID == guildsarray[selectedindex].ID)
                    {
                        richTextBox1.AppendText(playerList[i].Name + '\t' + playerList[i].Level + '\t' + playerList[i].Race + '\n');
                    }
                }
            }
        }

        private void joinGuild_Click(object sender, EventArgs e)
        {
            if (selectedplayerindex != -1 && selectedindex != -1)
            {
                if(playerList[selectedplayerindex].GuildID == 0)
                {
                    playerList[selectedplayerindex].GuildID = guildsarray[selectedindex].ID;
                }
                else
                {
                    richTextBox1.Text = "Already in a guild, please leave to join.";
                }
            }
        }
    }

    public class Player
    {
        private readonly uint id;
        private readonly string name;
        private readonly Race race;
        private readonly Class playerClass;
        private readonly Role playerRoles;
        private uint exp;
        private uint level;
        private uint guildID;

        public uint ID
        {
            get { return id; }
        }

        public String Name
        {
            get { return name; }
        }

        public Race Race
        {
            get { return race; }
        }

        public uint Level
        {
            get { return level; }

            set
            {
                if (value >= 0 && value <= 60)
                    level = value;

                else
                {
                    level = 0;
                }

            }
        }

        public uint Exp
        {
            get { return exp; }

            set
            {
                uint nextLevel = level * 1000;
                exp += value;
            }
        }

        public uint GuildID
        {
            get { return guildID; }

            set { guildID = value; }
        }

        public Player()
        {
            id = 0;
            name = "";
            race = 0;
            level = 0;
            guildID = 0;
        }

        public Player(uint newID, string newName, Race newRace, Class newClass, uint newLevel, uint newExp, uint newGuildID)
        {
            id = newID;
            name = newName;
            race = newRace;
            level = newLevel;
            guildID = newGuildID;
            playerClass = newClass;
            exp = newExp;
        }

        public override string ToString()
        {
            return String.Format("{0, -25} {1, -15} {2, -2}", name, playerClass, level);
        }
    }
    class Guild
    {
        private uint id;
        private string name;
        private string server;

        public uint ID
        {
            get { return id; }
        }

        public string Name
        {
            get { return name; }
        }

        public string Server
        {
            get { return server; }
        }
        public Guild(uint guildid, string guildname, string servername)
        {
            id = guildid;
            name = guildname;
            server = servername;
        }
        public Guild()
        {
            id = 0;
            name = "";
            server = "";
        }
    }
}
